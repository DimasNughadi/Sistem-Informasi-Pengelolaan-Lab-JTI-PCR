package Model;

import com.mysql.jdbc.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserHome {

    public User[] getDataUser(String username, String password) {
        User[] daftarUser = null;
        User tempUser = null;
        ArrayList listUser = new ArrayList();

        String pwd = "";
        String login = "root";
        Connection con = null;

        ResultSet rs = null;

        KoneksiDB db = new KoneksiDB("multilogin", login, pwd);
        String sql = "SELECT * FROM user where username='" + username + "' and password='" + password + "'";
        try {
            con = db.connect();
            rs = db.executeQuery(sql);
            while (rs.next()) {
                tempUser = new User();
                tempUser.setId(rs.getString("id"));
                tempUser.setUsername(rs.getString("username"));
                tempUser.setPassword(rs.getString("password"));
                tempUser.setHak_akses(rs.getString("hak_akses"));
                listUser.add(tempUser);
            }
            daftarUser = new User[listUser.size()];
            listUser.toArray(daftarUser);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                db.disconnect();
                return daftarUser;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}
